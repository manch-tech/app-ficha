-- SQL para Supabase - Rode no SQL Editor
create table if not exists docs (
  id text primary key,
  titulo text not null,
  url text not null,
  descricao text,
  obrigatorio boolean default true,
  created_at timestamp with time zone default now()
);

create table if not exists codigos (
  codigo text primary key,
  empresa text,
  data text,
  status text,
  usadoEm text,
  created_at timestamp with time zone default now()
);

create table if not exists fichas (
  protocolo text primary key,
  dados jsonb not null,
  created_at timestamp with time zone default now()
);

-- Libera acesso (para teste, depois você pode travar com auth)
alter table docs enable row level security;
alter table codigos enable row level security;
alter table fichas enable row level security;

drop policy if exists "libera tudo" on docs;
create policy "libera tudo" on docs for all using(true) with check(true);

drop policy if exists "libera tudo" on codigos;
create policy "libera tudo" on codigos for all using(true) with check(true);

drop policy if exists "libera tudo" on fichas;
create policy "libera tudo" on fichas for all using(true) with check(true);
